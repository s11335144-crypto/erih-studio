function getOrders() {
  return JSON.parse(localStorage.getItem("orders") || "[]");
}

function saveOrders(list) {
  localStorage.setItem("orders", JSON.stringify(list));
}

function submitOrder() {
  let name = document.getElementById("name").value;
  let desc = document.getElementById("desc").value;
  let email = document.getElementById("email").value;

  let orders = getOrders();
  orders.push({
    name,
    desc,
    email,
    status: "pending"
  });

  saveOrders(orders);
  alert("訂單送出成功！");
}

function loadAdmin() {
  let container = document.getElementById("orders");
  if (!container) return;

  let orders = getOrders();
  container.innerHTML = "";

  orders.forEach((o, i) => {
    container.innerHTML += `
      <div class="card">
        <p><b>${o.name}</b></p>
        <p>${o.desc}</p>
        <p>${o.email}</p>
        <p>狀態：${o.status}</p>

        <button class="pixel-btn" onclick="accept(${i})">接受</button>
        <button class="pixel-btn" onclick="reject(${i})">拒絕</button>
        <button class="pixel-btn" onclick="finish(${i})">完成</button>
      </div>
    `;
  });
}

function accept(i) {
  let orders = getOrders();
  orders[i].status = "accepted";
  saveOrders(orders);
  loadAdmin();
}

function reject(i) {
  let orders = getOrders();
  orders[i].status = "rejected";
  saveOrders(orders);
  loadAdmin();
}

function finish(i) {
  let orders = getOrders();
  orders[i].status = "done";
  saveOrders(orders);
  loadAdmin();
}

loadAdmin();